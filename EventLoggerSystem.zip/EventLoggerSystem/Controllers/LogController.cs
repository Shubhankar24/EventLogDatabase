﻿using EventLoggerSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Storage.Json;

namespace EventLoggerSystem.Controllers
{
    public class LogController : Controller
    {
        public EventLogDb context;

        public LogController(EventLogDb _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            List<Log> log = context.Logs.ToList();
            return View(log);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Log l)
        {
            context.Logs.Add(l);
            context.SaveChanges();
            return RedirectToAction("Index");

          
        }

        //[HttpPost]
        //public IActionResult Create(string EventType, string Message, DateTime LoggedAt)
        //{
        //    Log l = new Log();
        //    l.EventType = EventType;
        //    l.Message = Message;
        //    l.LoggedAt = LoggedAt;
        //    context.Logs.Add(l);
        //    context.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Log log = context.Logs.Find(id);
            return View(log);
        }

        [HttpPost]
        public IActionResult Edit(Log l)
        {
            Log log = context.Logs.Find(l.Id);
            log.EventType = l.EventType;
            log.Message = l.Message;
            log.LoggedAt = l.LoggedAt;
            context.Update(log);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            Log log = context.Logs.Find(id);
            return View(log);
        }

        //before deleting it 
        [HttpGet]
        public IActionResult Delete (int id)
        {
            Log log = context.Logs.Find(id);
            return View(log);
        }

        // confirm delete it 
        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            Log log = context.Logs.Find(id);
            context.Logs.Remove(log);
            context.SaveChanges();
            return RedirectToAction("Index");
        }


    }
}
