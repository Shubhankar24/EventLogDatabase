﻿using Microsoft.EntityFrameworkCore;

namespace EventLoggerSystem.Models
{
    public class EventLogDb:DbContext
    {
        public EventLogDb(DbContextOptions<EventLogDb> options) : base(options) { }

        public DbSet<Log> Logs { get; set; }
    }
}
