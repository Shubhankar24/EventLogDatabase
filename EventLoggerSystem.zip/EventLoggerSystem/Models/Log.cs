﻿using System.ComponentModel.DataAnnotations;

namespace EventLoggerSystem.Models
{
    public class Log
    {
        // id(int), EventType(string), Message(string), LoggedAt(DateTime)

        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage ="EventType is Required !")]
        public string EventType { get; set; }

        [Required(ErrorMessage ="Message is Required !")]
        public string Message { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime LoggedAt { get; set; }

    }
}
